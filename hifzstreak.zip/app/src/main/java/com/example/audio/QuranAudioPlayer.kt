package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.os.Build
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class PlaybackState {
    IDLE,
    PREPARING,
    PLAYING,
    PAUSED,
    ERROR
}

data class Reciter(
    val id: String,
    val name: String,
    val style: String
)

data class AudioPlayerState(
    val playbackState: PlaybackState = PlaybackState.IDLE,
    val currentVerseId: Int? = null,
    val currentLoop: Int = 0,
    val targetLoops: Int = 3, // 1, 3, 5, 10, -1 (Infinite)
    val isMuted: Boolean = false,
    val playbackSpeed: Float = 1.0f,
    val currentReciterId: String = "Alafasy_128kbps",
    val errorMessage: String? = null
)

class QuranAudioPlayer(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private var onLoopFinishedCallback: ((verseId: Int) -> Unit)? = null

    private val _playerState = MutableStateFlow(AudioPlayerState())
    val playerState: StateFlow<AudioPlayerState> = _playerState.asStateFlow()

    companion object {
        val AVAILABLE_RECITERS = listOf(
            Reciter("Alafasy_128kbps", "Mishary Rashid Alafasy", "Melodious"),
            Reciter("Abdul_Basit_Murattal_192kbps", "Abdul Basit Abdul Samad", "Traditional Murattal"),
            Reciter("Ghamadi_40kbps", "Saad Al-Ghamdi", "Warm & Clear"),
            Reciter("Husary_128kbps", "Mahmoud Khalil Al-Husary", "Precision Tajweed")
        )
    }

    fun setOnLoopFinishedListener(listener: (verseId: Int) -> Unit) {
        onLoopFinishedCallback = listener
    }

    fun playVerse(
        verseId: Int,
        audioUrl: String,
        targetLoops: Int = _playerState.value.targetLoops
    ) {
        // If already playing this verse and paused, simply resume
        if (_playerState.value.currentVerseId == verseId && mediaPlayer != null) {
            if (_playerState.value.playbackState == PlaybackState.PAUSED) {
                resume()
                return
            }
        }

        stop()

        _playerState.value = _playerState.value.copy(
            playbackState = PlaybackState.PREPARING,
            currentVerseId = verseId,
            currentLoop = 1,
            targetLoops = targetLoops,
            errorMessage = null
        )

        try {
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(audioUrl)
                setOnPreparedListener { mp ->
                    applySpeedAndVolume(mp)
                    mp.start()
                    _playerState.value = _playerState.value.copy(playbackState = PlaybackState.PLAYING)
                }
                setOnCompletionListener { mp ->
                    handleCompletion(verseId, audioUrl, mp)
                }
                setOnErrorListener { _, what, extra ->
                    Log.e("QuranAudioPlayer", "MediaPlayer error: what=$what, extra=$extra")
                    _playerState.value = _playerState.value.copy(
                        playbackState = PlaybackState.ERROR,
                        errorMessage = "Audio streaming failed. Please check internet connection."
                    )
                    true
                }
                prepareAsync()
            }
            mediaPlayer = player
        } catch (e: Exception) {
            Log.e("QuranAudioPlayer", "Error initializing player", e)
            _playerState.value = _playerState.value.copy(
                playbackState = PlaybackState.ERROR,
                errorMessage = e.localizedMessage ?: "Failed to start audio"
            )
        }
    }

    private fun handleCompletion(verseId: Int, audioUrl: String, mp: MediaPlayer) {
        val currentState = _playerState.value
        onLoopFinishedCallback?.invoke(verseId)

        val targetLoops = currentState.targetLoops
        val nextLoop = currentState.currentLoop + 1

        if (targetLoops == -1 || nextLoop <= targetLoops) {
            // Repeat again!
            _playerState.value = currentState.copy(
                currentLoop = nextLoop,
                playbackState = PlaybackState.PLAYING
            )
            try {
                mp.seekTo(0)
                applySpeedAndVolume(mp)
                mp.start()
            } catch (e: Exception) {
                // If seeking fails, re-prepare
                playVerse(verseId, audioUrl, targetLoops)
            }
        } else {
            // Target loops reached
            _playerState.value = currentState.copy(
                playbackState = PlaybackState.IDLE,
                currentLoop = targetLoops
            )
        }
    }

    fun pause() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                _playerState.value = _playerState.value.copy(playbackState = PlaybackState.PAUSED)
            }
        }
    }

    fun resume() {
        mediaPlayer?.let {
            it.start()
            _playerState.value = _playerState.value.copy(playbackState = PlaybackState.PLAYING)
        }
    }

    fun stop() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.reset()
                it.release()
            }
        } catch (e: Exception) {
            Log.e("QuranAudioPlayer", "Error stopping player", e)
        } finally {
            mediaPlayer = null
            _playerState.value = _playerState.value.copy(
                playbackState = PlaybackState.IDLE,
                currentVerseId = null
            )
        }
    }

    fun setTargetLoops(loops: Int) {
        _playerState.value = _playerState.value.copy(targetLoops = loops)
    }

    fun toggleMute() {
        val newMute = !_playerState.value.isMuted
        _playerState.value = _playerState.value.copy(isMuted = newMute)
        mediaPlayer?.let { applySpeedAndVolume(it) }
    }

    fun setSpeed(speed: Float) {
        _playerState.value = _playerState.value.copy(playbackSpeed = speed)
        mediaPlayer?.let { applySpeedAndVolume(it) }
    }

    fun setReciter(reciterId: String) {
        _playerState.value = _playerState.value.copy(currentReciterId = reciterId)
    }

    private fun applySpeedAndVolume(mp: MediaPlayer) {
        try {
            val volume = if (_playerState.value.isMuted) 0f else 1f
            mp.setVolume(volume, volume)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val params = mp.playbackParams ?: PlaybackParams()
                params.speed = _playerState.value.playbackSpeed
                mp.playbackParams = params
            }
        } catch (e: Exception) {
            Log.w("QuranAudioPlayer", "Could not apply speed/volume", e)
        }
    }

    fun release() {
        stop()
    }
}
