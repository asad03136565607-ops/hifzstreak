package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.LocalFireDepartment
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.QuranViewModel
import com.example.ui.components.CelebrationDialog
import com.example.ui.components.RedCountBadge
import com.example.ui.components.ShareVerseDialog
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StreaksAndBadgesScreen
import com.example.ui.screens.SurahLibraryScreen
import com.example.ui.screens.TodayScreen
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MyApplicationTheme

enum class MainTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    TODAY("Today", Icons.Default.MenuBook, Icons.Outlined.MenuBook, "tab_today"),
    SURAHS("Surahs", Icons.Default.AutoStories, Icons.Outlined.AutoStories, "tab_surahs"),
    STREAKS("Streaks", Icons.Default.LocalFireDepartment, Icons.Outlined.LocalFireDepartment, "tab_streaks"),
    SETTINGS("Settings", Icons.Default.Tune, Icons.Outlined.Tune, "tab_settings")
}

class MainActivity : ComponentActivity() {

    private val viewModel: QuranViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                var currentTab by rememberSaveable { mutableStateOf(MainTab.TODAY) }

                // Handle back press to return to Today tab
                BackHandler(enabled = currentTab != MainTab.TODAY) {
                    currentTab = MainTab.TODAY
                }

                val unreadCount = uiState.todayPendingVerses.count { !it.isMemorized }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(
                            modifier = Modifier
                                .testTag("main_bottom_nav")
                                .windowInsetsPadding(WindowInsets.navigationBars),
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 4.dp
                        ) {
                            MainTab.values().forEach { tab ->
                                val isSelected = currentTab == tab
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { currentTab = tab },
                                    icon = {
                                        if (tab == MainTab.TODAY && unreadCount > 0) {
                                            BadgedBox(
                                                badge = { RedCountBadge(count = unreadCount) }
                                            ) {
                                                Icon(
                                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                                    contentDescription = tab.title
                                                )
                                            }
                                        } else {
                                            Icon(
                                                imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                                contentDescription = tab.title
                                            )
                                        }
                                    },
                                    label = { Text(tab.title) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = EmeraldDeep,
                                        selectedTextColor = EmeraldDeep,
                                        indicatorColor = EmeraldContainer,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            MainTab.TODAY -> TodayScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                onNavigateToSettings = { currentTab = MainTab.SETTINGS }
                            )
                            MainTab.SURAHS -> SurahLibraryScreen(
                                uiState = uiState,
                                viewModel = viewModel
                            )
                            MainTab.STREAKS -> StreaksAndBadgesScreen(
                                uiState = uiState,
                                viewModel = viewModel
                            )
                            MainTab.SETTINGS -> SettingsScreen(
                                uiState = uiState,
                                viewModel = viewModel
                            )
                        }

                        // Celebration Dialog on Goal Achievement
                        if (uiState.showCelebration) {
                            CelebrationDialog(
                                streakCount = uiState.celebrationStreak,
                                onDismiss = { viewModel.dismissCelebration() },
                                onShareAchievement = {
                                    viewModel.dismissCelebration()
                                    currentTab = MainTab.STREAKS
                                }
                            )
                        }

                        // Shareable Verse Dialog
                        uiState.selectedVerseForShare?.let { verse ->
                            ShareVerseDialog(
                                verse = verse,
                                streakCount = uiState.userProgress.currentStreak,
                                onDismiss = { viewModel.closeShareDialog() }
                            )
                        }
                    }
                }
            }
        }
    }
}
