package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_progress")
data class UserProgressEntity(
    @PrimaryKey val id: Int = 1,
    val currentStreak: Int = 4,
    val maxStreak: Int = 7,
    val lastCompletedDate: String = "", // e.g., "2026-10-03"
    val dailyGoalVerses: Int = 2,
    val targetSurahNumber: Int = 1,
    val selectedReciterId: String = "Alafasy_128kbps",
    val defaultLoopCount: Int = 3,
    val reminderTime: String = "05:00 AM (Fajr)",
    val notificationsEnabled: Boolean = true,
    val streakFreezeAvailable: Int = 1,
    val totalAudioLoopsDone: Int = 18
)
