package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.BadgeEntity
import com.example.data.model.UserProgressEntity
import com.example.data.model.VerseEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface QuranDao {

    @Query("SELECT * FROM verses ORDER BY surahNumber ASC, ayahNumber ASC")
    fun getAllVerses(): Flow<List<VerseEntity>>

    @Query("SELECT * FROM verses WHERE surahNumber = :surahNumber ORDER BY ayahNumber ASC")
    fun getVersesBySurah(surahNumber: Int): Flow<List<VerseEntity>>

    @Query("SELECT * FROM verses WHERE surahNumber = :surahNumber AND isMemorized = 0 ORDER BY ayahNumber ASC LIMIT :limit")
    fun getPendingVersesForTarget(surahNumber: Int, limit: Int): Flow<List<VerseEntity>>

    @Query("SELECT COUNT(*) FROM verses WHERE isMemorized = 1")
    fun getMemorizedCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM verses WHERE surahNumber = :surahNumber AND isMemorized = 1")
    fun getMemorizedCountForSurah(surahNumber: Int): Flow<Int>

    @Query("SELECT COUNT(*) FROM verses WHERE surahNumber = :surahNumber")
    fun getTotalCountForSurah(surahNumber: Int): Flow<Int>

    @Query("UPDATE verses SET isMemorized = :isMemorized, memorizedDate = :timestamp WHERE id = :verseId")
    suspend fun setVerseMemorized(verseId: Int, isMemorized: Boolean, timestamp: Long)

    @Query("UPDATE verses SET repeatCount = repeatCount + 1 WHERE id = :verseId")
    suspend fun incrementVerseRepeat(verseId: Int)

    @Query("UPDATE verses SET isBookmarked = :isBookmarked WHERE id = :verseId")
    suspend fun setBookmark(verseId: Int, isBookmarked: Boolean)

    @Query("SELECT * FROM user_progress WHERE id = 1 LIMIT 1")
    fun getUserProgress(): Flow<UserProgressEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUserProgress(progress: UserProgressEntity)

    @Query("UPDATE user_progress SET currentStreak = :streak, maxStreak = :maxStreak, lastCompletedDate = :date WHERE id = 1")
    suspend fun updateStreak(streak: Int, maxStreak: Int, date: String)

    @Query("UPDATE user_progress SET dailyGoalVerses = :goal WHERE id = 1")
    suspend fun updateDailyGoal(goal: Int)

    @Query("UPDATE user_progress SET targetSurahNumber = :surahNumber WHERE id = 1")
    suspend fun updateTargetSurah(surahNumber: Int)

    @Query("UPDATE user_progress SET selectedReciterId = :reciterId WHERE id = 1")
    suspend fun updateReciter(reciterId: String)

    @Query("UPDATE user_progress SET defaultLoopCount = :loopCount WHERE id = 1")
    suspend fun updateDefaultLoop(loopCount: Int)

    @Query("UPDATE user_progress SET reminderTime = :time, notificationsEnabled = :enabled WHERE id = 1")
    suspend fun updateReminderSettings(time: String, enabled: Boolean)

    @Query("UPDATE user_progress SET totalAudioLoopsDone = totalAudioLoopsDone + 1 WHERE id = 1")
    suspend fun incrementTotalAudioLoops()

    @Query("UPDATE user_progress SET streakFreezeAvailable = streakFreezeAvailable - 1 WHERE id = 1 AND streakFreezeAvailable > 0")
    suspend fun useStreakFreeze(): Int

    @Query("SELECT * FROM badges ORDER BY isUnlocked DESC, id ASC")
    fun getAllBadges(): Flow<List<BadgeEntity>>

    @Query("UPDATE badges SET isUnlocked = 1, unlockedAt = :timestamp WHERE id = :badgeId")
    suspend fun unlockBadge(badgeId: String, timestamp: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertVerses(verses: List<VerseEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertBadges(badges: List<BadgeEntity>)

    @Query("SELECT COUNT(*) FROM verses")
    suspend fun getVerseCountSync(): Int
}
