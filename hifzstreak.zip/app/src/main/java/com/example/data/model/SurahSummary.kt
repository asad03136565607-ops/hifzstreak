package com.example.data.model

data class SurahSummary(
    val number: Int,
    val nameArabic: String,
    val nameEnglish: String,
    val nameUrdu: String,
    val totalVerses: Int,
    val memorizedVerses: Int,
    val isComplete: Boolean = memorizedVerses >= totalVerses && totalVerses > 0,
    val progressPercent: Float = if (totalVerses > 0) (memorizedVerses.toFloat() / totalVerses).coerceIn(0f, 1f) else 0f
)
