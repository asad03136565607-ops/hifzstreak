package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "verses")
data class VerseEntity(
    @PrimaryKey val id: Int, // surahNumber * 1000 + ayahNumber
    val surahNumber: Int,
    val surahNameArabic: String,
    val surahNameEnglish: String,
    val surahNameUrdu: String,
    val ayahNumber: Int,
    val arabicText: String,
    val romanTransliteration: String,
    val urduTranslation: String,
    val englishTranslation: String,
    val isMemorized: Boolean = false,
    val memorizedDate: Long? = null,
    val repeatCount: Int = 0,
    val isBookmarked: Boolean = false
) {
    /**
     * Formats URL for EveryAyah recitation CDN
     */
    fun getAudioUrl(reciterId: String): String {
        val sStr = surahNumber.toString().padStart(3, '0')
        val aStr = ayahNumber.toString().padStart(3, '0')
        return "https://everyayah.com/data/$reciterId/$sStr$aStr.mp3"
    }

    val referenceStr: String
        get() = "$surahNameEnglish $surahNumber:$ayahNumber"
}
