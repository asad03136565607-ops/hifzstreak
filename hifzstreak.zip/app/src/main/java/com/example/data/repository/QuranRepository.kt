package com.example.data.repository

import com.example.data.db.QuranDao
import com.example.data.db.QuranInitialData
import com.example.data.model.BadgeEntity
import com.example.data.model.SurahSummary
import com.example.data.model.UserProgressEntity
import com.example.data.model.VerseEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class QuranRepository(private val dao: QuranDao) {

    val allVerses: Flow<List<VerseEntity>> = dao.getAllVerses()
    val userProgress: Flow<UserProgressEntity?> = dao.getUserProgress()
    val allBadges: Flow<List<BadgeEntity>> = dao.getAllBadges()

    suspend fun ensureInitialData() {
        val count = dao.getVerseCountSync()
        if (count == 0) {
            dao.insertVerses(QuranInitialData.getInitialVerses())
            dao.insertBadges(QuranInitialData.getInitialBadges())
            dao.saveUserProgress(UserProgressEntity())
        }
    }

    fun getVersesBySurah(surahNumber: Int): Flow<List<VerseEntity>> {
        return dao.getVersesBySurah(surahNumber)
    }

    fun getPendingVerses(surahNumber: Int, limit: Int): Flow<List<VerseEntity>> {
        return dao.getPendingVersesForTarget(surahNumber, limit)
    }

    val surahSummaries: Flow<List<SurahSummary>> = dao.getAllVerses().map { verses ->
        verses.groupBy { it.surahNumber }.map { (surahNum, list) ->
            val first = list.first()
            val total = list.size
            val memorized = list.count { it.isMemorized }
            SurahSummary(
                number = surahNum,
                nameArabic = first.surahNameArabic,
                nameEnglish = first.surahNameEnglish,
                nameUrdu = first.surahNameUrdu,
                totalVerses = total,
                memorizedVerses = memorized
            )
        }.sortedBy { it.number }
    }

    suspend fun markVerseMemorized(verseId: Int, isMemorized: Boolean): Boolean {
        val now = System.currentTimeMillis()
        dao.setVerseMemorized(verseId, isMemorized, if (isMemorized) now else 0L)

        // Check if daily goal reached
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val progress = dao.getUserProgress().firstOrNull() ?: UserProgressEntity()

        var goalCompletedToday = false
        if (isMemorized) {
            // Count verses memorized today or check target
            val pendingToday = dao.getPendingVersesForTarget(progress.targetSurahNumber, progress.dailyGoalVerses).firstOrNull()
            if (pendingToday.isNullOrEmpty() || progress.lastCompletedDate != todayStr) {
                // User has made progress today
                val newStreak = if (progress.lastCompletedDate == todayStr) {
                    progress.currentStreak
                } else {
                    goalCompletedToday = true
                    progress.currentStreak + 1
                }
                val newMax = maxOf(newStreak, progress.maxStreak)
                dao.updateStreak(newStreak, newMax, todayStr)

                // Check streak badges
                if (newStreak >= 3) dao.unlockBadge("streak_3", now)
                if (newStreak >= 7) dao.unlockBadge("streak_7", now)
                if (newStreak >= 30) dao.unlockBadge("streak_30", now)
            }

            // Check Surah completion badges
            checkSurahBadges(now)
        }

        return goalCompletedToday
    }

    private suspend fun checkSurahBadges(now: Long) {
        val fatihaPending = dao.getPendingVersesForTarget(1, 10).firstOrNull()
        if (fatihaPending != null && fatihaPending.isEmpty()) {
            dao.unlockBadge("fatiha_done", now)
        }
        val ikhlasPending = dao.getPendingVersesForTarget(112, 10).firstOrNull()
        if (ikhlasPending != null && ikhlasPending.isEmpty()) {
            dao.unlockBadge("ikhlas_done", now)
        }
    }

    suspend fun incrementRepeat(verseId: Int) {
        dao.incrementVerseRepeat(verseId)
        dao.incrementTotalAudioLoops()
        val progress = dao.getUserProgress().firstOrNull()
        if ((progress?.totalAudioLoopsDone ?: 0) >= 50) {
            dao.unlockBadge("loop_master", System.currentTimeMillis())
        }
    }

    suspend fun setTargetSurah(surahNumber: Int) {
        dao.updateTargetSurah(surahNumber)
    }

    suspend fun setDailyGoal(goal: Int) {
        dao.updateDailyGoal(goal)
    }

    suspend fun setReciter(reciterId: String) {
        dao.updateReciter(reciterId)
    }

    suspend fun setDefaultLoop(loopCount: Int) {
        dao.updateDefaultLoop(loopCount)
    }

    suspend fun updateReminder(time: String, enabled: Boolean) {
        dao.updateReminderSettings(time, enabled)
    }

    suspend fun useFreeze(): Boolean {
        val updated = dao.useStreakFreeze()
        return updated > 0
    }
}
