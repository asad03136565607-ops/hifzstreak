package com.example.data.db

import com.example.data.model.BadgeEntity
import com.example.data.model.VerseEntity

object QuranInitialData {

    fun getInitialVerses(): List<VerseEntity> {
        val list = mutableListOf<VerseEntity>()

        // 1. Surah Al-Fatihah (1)
        list.add(
            VerseEntity(
                id = 1001,
                surahNumber = 1,
                surahNameArabic = "الفاتحة",
                surahNameEnglish = "Al-Fatihah",
                surahNameUrdu = "سورۃ الفاتحہ",
                ayahNumber = 1,
                arabicText = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
                romanTransliteration = "Bismillāhir-Raḥmānir-Raḥīm",
                urduTranslation = "شروع اللہ کے نام سے جو بڑا مہربان نہایت رحم والا ہے",
                englishTranslation = "In the name of Allah, the Entirely Merciful, the Especially Merciful.",
                isMemorized = true,
                repeatCount = 12
            )
        )
        list.add(
            VerseEntity(
                id = 1002,
                surahNumber = 1,
                surahNameArabic = "الفاتحة",
                surahNameEnglish = "Al-Fatihah",
                surahNameUrdu = "سورۃ الفاتحہ",
                ayahNumber = 2,
                arabicText = "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
                romanTransliteration = "Al-ḥamdu lillāhi Rabbil-'ālamīn",
                urduTranslation = "سب تعریف اللہ ہی کے لیے ہے جو تمام جہانوں کا پروردگار ہے",
                englishTranslation = "[All] praise is [due] to Allah, Lord of the worlds.",
                isMemorized = true,
                repeatCount = 10
            )
        )
        list.add(
            VerseEntity(
                id = 1003,
                surahNumber = 1,
                surahNameArabic = "الفاتحة",
                surahNameEnglish = "Al-Fatihah",
                surahNameUrdu = "سورۃ الفاتحہ",
                ayahNumber = 3,
                arabicText = "الرَّحْمَٰنِ الرَّحِيمِ",
                romanTransliteration = "Ar-Raḥmānir-Raḥīm",
                urduTranslation = "بڑا مہربان، نہایت رحم کرنے والا",
                englishTranslation = "The Entirely Merciful, the Especially Merciful.",
                isMemorized = false,
                repeatCount = 4
            )
        )
        list.add(
            VerseEntity(
                id = 1004,
                surahNumber = 1,
                surahNameArabic = "الفاتحة",
                surahNameEnglish = "Al-Fatihah",
                surahNameUrdu = "سورۃ الفاتحہ",
                ayahNumber = 4,
                arabicText = "مَالِكِ يَوْمِ الدِّينِ",
                romanTransliteration = "Māliki Yawmid-Dīn",
                urduTranslation = "روزِ جزا کا مالک ہے",
                englishTranslation = "Sovereign of the Day of Recompense.",
                isMemorized = false,
                repeatCount = 1
            )
        )
        list.add(
            VerseEntity(
                id = 1005,
                surahNumber = 1,
                surahNameArabic = "الفاتحة",
                surahNameEnglish = "Al-Fatihah",
                surahNameUrdu = "سورۃ الفاتحہ",
                ayahNumber = 5,
                arabicText = "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ",
                romanTransliteration = "Iyyāka na'budu wa iyyāka nasta'īn",
                urduTranslation = "ہم تیری ہی عبادت کرتے ہیں اور تجھ ہی سے مدد مانگتے ہیں",
                englishTranslation = "It is You we worship and You we ask for help.",
                isMemorized = false,
                repeatCount = 0
            )
        )
        list.add(
            VerseEntity(
                id = 1006,
                surahNumber = 1,
                surahNameArabic = "الفاتحة",
                surahNameEnglish = "Al-Fatihah",
                surahNameUrdu = "سورۃ الفاتحہ",
                ayahNumber = 6,
                arabicText = "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ",
                romanTransliteration = "Ihdinaṣ-ṣirāṭal-mustaqīm",
                urduTranslation = "ہم کو سیدھے راستے پر چلا",
                englishTranslation = "Guide us to the straight path.",
                isMemorized = false,
                repeatCount = 0
            )
        )
        list.add(
            VerseEntity(
                id = 1007,
                surahNumber = 1,
                surahNameArabic = "الفاتحة",
                surahNameEnglish = "Al-Fatihah",
                surahNameUrdu = "سورۃ الفاتحہ",
                ayahNumber = 7,
                arabicText = "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ",
                romanTransliteration = "Ṣirāṭallaḏīna an'amta 'alayhim ghayril-maghḍūbi 'alayhim walāḍ-ḍāllīn",
                urduTranslation = "ان لوگوں کا راستہ جن پر تو نے انعام فرمایا، نہ ان کا جن پر غضب ہوا اور نہ گمراہوں کا",
                englishTranslation = "The path of those upon whom You have bestowed favor, not of those who have evoked [Your] anger or of those who are astray.",
                isMemorized = false,
                repeatCount = 0
            )
        )

        // 2. Ayat Al-Kursi (2:255)
        list.add(
            VerseEntity(
                id = 2255,
                surahNumber = 2,
                surahNameArabic = "البقرة",
                surahNameEnglish = "Al-Baqarah",
                surahNameUrdu = "آیت الکرسی (البقرہ)",
                ayahNumber = 255,
                arabicText = "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ",
                romanTransliteration = "Allāhu lā ilāha illā Huwal-Ḥayyul-Qayyūm, lā ta'khuḏuhū sinatuw-walā nawm, lahū mā fis-samāwāti wamā fil-arḍ",
                urduTranslation = "اللہ، اس کے سوا کوئی معبود نہیں، وہ زندہ ہے سب کا تھامنے والا، اسے نہ اونگھ آتی ہے نہ نیند، جو کچھ آسمانوں اور زمین میں ہے اسی کا ہے",
                englishTranslation = "Allah! There is no deity except Him, the Ever-Living, the Sustainer of all existence. Neither drowsiness overtakes Him nor sleep.",
                isMemorized = false,
                repeatCount = 2
            )
        )

        // 3. Surah Al-Ikhlas (112:1-4)
        list.add(
            VerseEntity(
                id = 112001,
                surahNumber = 112,
                surahNameArabic = "الإخلاص",
                surahNameEnglish = "Al-Ikhlas",
                surahNameUrdu = "سورۃ الاخلاص",
                ayahNumber = 1,
                arabicText = "قُلْ هُوَ اللَّهُ أَحَدٌ",
                romanTransliteration = "Qul Huwal-Lāhu Aḥad",
                urduTranslation = "کہہ دو کہ وہ اللہ ایک ہے",
                englishTranslation = "Say, 'He is Allah, [who is] One.'",
                isMemorized = true,
                repeatCount = 15
            )
        )
        list.add(
            VerseEntity(
                id = 112002,
                surahNumber = 112,
                surahNameArabic = "الإخلاص",
                surahNameEnglish = "Al-Ikhlas",
                surahNameUrdu = "سورۃ الاخلاص",
                ayahNumber = 2,
                arabicText = "اللَّهُ الصَّمَدُ",
                romanTransliteration = "Allāhuṣ-Ṣamad",
                urduTranslation = "اللہ بے نیاز ہے",
                englishTranslation = "Allah, the Eternal Refuge.",
                isMemorized = true,
                repeatCount = 15
            )
        )
        list.add(
            VerseEntity(
                id = 112003,
                surahNumber = 112,
                surahNameArabic = "الإخلاص",
                surahNameEnglish = "Al-Ikhlas",
                surahNameUrdu = "سورۃ الاخلاص",
                ayahNumber = 3,
                arabicText = "لَمْ يَلِدْ وَلَمْ يُولَدْ",
                romanTransliteration = "Lam yalid wa lam yūlad",
                urduTranslation = "نہ اس کی کوئی اولاد ہے اور نہ وہ کسی کی اولاد ہے",
                englishTranslation = "He neither begets nor is born,",
                isMemorized = true,
                repeatCount = 14
            )
        )
        list.add(
            VerseEntity(
                id = 112004,
                surahNumber = 112,
                surahNameArabic = "الإخلاص",
                surahNameEnglish = "Al-Ikhlas",
                surahNameUrdu = "سورۃ الاخلاص",
                ayahNumber = 4,
                arabicText = "وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ",
                romanTransliteration = "Wa lam yakul-lahū kufuwan aḥad",
                urduTranslation = "اور کوئی اس کا ہمسر نہیں ہے",
                englishTranslation = "Nor is there to Him any equivalent.",
                isMemorized = true,
                repeatCount = 14
            )
        )

        // 4. Surah Al-Falaq (113:1-5)
        list.add(
            VerseEntity(
                id = 113001,
                surahNumber = 113,
                surahNameArabic = "الفلق",
                surahNameEnglish = "Al-Falaq",
                surahNameUrdu = "سورۃ الفلق",
                ayahNumber = 1,
                arabicText = "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ",
                romanTransliteration = "Qul a'ūḏu bi Rabbil-falaq",
                urduTranslation = "کہو کہ میں صبح کے رب کی پناہ مانگتا ہوں",
                englishTranslation = "Say, 'I seek refuge in the Lord of daybreak.'",
                isMemorized = false,
                repeatCount = 0
            )
        )
        list.add(
            VerseEntity(
                id = 113002,
                surahNumber = 113,
                surahNameArabic = "الفلق",
                surahNameEnglish = "Al-Falaq",
                surahNameUrdu = "سورۃ الفلق",
                ayahNumber = 2,
                arabicText = "مِن شَرِّ مَا خَلَقَ",
                romanTransliteration = "Min sharri mā khalaq",
                urduTranslation = "ہر اس چیز کی برائی سے جو اس نے پیدا کی",
                englishTranslation = "From the evil of that which He created,",
                isMemorized = false,
                repeatCount = 0
            )
        )
        list.add(
            VerseEntity(
                id = 113003,
                surahNumber = 113,
                surahNameArabic = "الفلق",
                surahNameEnglish = "Al-Falaq",
                surahNameUrdu = "سورۃ الفلق",
                ayahNumber = 3,
                arabicText = "وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ",
                romanTransliteration = "Wa min sharri ghāsiqin iḏā waqab",
                urduTranslation = "اور اندھیری رات کی برائی سے جب وہ چھا جائے",
                englishTranslation = "And from the evil of darkness when it settles,",
                isMemorized = false,
                repeatCount = 0
            )
        )
        list.add(
            VerseEntity(
                id = 113004,
                surahNumber = 113,
                surahNameArabic = "الفلق",
                surahNameEnglish = "Al-Falaq",
                surahNameUrdu = "سورۃ الفلق",
                ayahNumber = 4,
                arabicText = "وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ",
                romanTransliteration = "Wa min sharrin-naffāthāti fil-'uqad",
                urduTranslation = "اور گرہوں میں پھونکنے والیوں کی برائی سے",
                englishTranslation = "And from the evil of the blowers in knots,",
                isMemorized = false,
                repeatCount = 0
            )
        )
        list.add(
            VerseEntity(
                id = 113005,
                surahNumber = 113,
                surahNameArabic = "الفلق",
                surahNameEnglish = "Al-Falaq",
                surahNameUrdu = "سورۃ الفلق",
                ayahNumber = 5,
                arabicText = "وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ",
                romanTransliteration = "Wa min sharri ḥāsidin iḏā ḥasad",
                urduTranslation = "اور حسد کرنے والے کی برائی سے جب وہ حسد کرے",
                englishTranslation = "And from the evil of an envier when he envies.",
                isMemorized = false,
                repeatCount = 0
            )
        )

        // 5. Surah An-Nas (114:1-6)
        list.add(
            VerseEntity(
                id = 114001,
                surahNumber = 114,
                surahNameArabic = "الناس",
                surahNameEnglish = "An-Nas",
                surahNameUrdu = "سورۃ الناس",
                ayahNumber = 1,
                arabicText = "قُلْ أَعُوذُ بِرَبِّ النَّاسِ",
                romanTransliteration = "Qul a'ūḏu bi Rabbin-nās",
                urduTranslation = "کہو کہ میں پناہ مانگتا ہوں انسانوں کے پروردگار کی",
                englishTranslation = "Say, 'I seek refuge in the Lord of mankind,'",
                isMemorized = false,
                repeatCount = 0
            )
        )
        list.add(
            VerseEntity(
                id = 114002,
                surahNumber = 114,
                surahNameArabic = "الناس",
                surahNameEnglish = "An-Nas",
                surahNameUrdu = "سورۃ الناس",
                ayahNumber = 2,
                arabicText = "مَلِكِ النَّاسِ",
                romanTransliteration = "Malikin-nās",
                urduTranslation = "انسانوں کے بادشاہ کی",
                englishTranslation = "The Sovereign of mankind,",
                isMemorized = false,
                repeatCount = 0
            )
        )
        list.add(
            VerseEntity(
                id = 114003,
                surahNumber = 114,
                surahNameArabic = "الناس",
                surahNameEnglish = "An-Nas",
                surahNameUrdu = "سورۃ الناس",
                ayahNumber = 3,
                arabicText = "إِلَٰهِ النَّاسِ",
                romanTransliteration = "Ilāhin-nās",
                urduTranslation = "انسانوں کے حقیقی معبود کی",
                englishTranslation = "The God of mankind,",
                isMemorized = false,
                repeatCount = 0
            )
        )
        list.add(
            VerseEntity(
                id = 114004,
                surahNumber = 114,
                surahNameArabic = "الناس",
                surahNameEnglish = "An-Nas",
                surahNameUrdu = "سورۃ الناس",
                ayahNumber = 4,
                arabicText = "مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ",
                romanTransliteration = "Min sharril-waswāsil-khannās",
                urduTranslation = "بار بار وسوسہ ڈال کر پیچھے ہٹ جانے والے کے شر سے",
                englishTranslation = "From the evil of the retreating whisperer -",
                isMemorized = false,
                repeatCount = 0
            )
        )
        list.add(
            VerseEntity(
                id = 114005,
                surahNumber = 114,
                surahNameArabic = "الناس",
                surahNameEnglish = "An-Nas",
                surahNameUrdu = "سورۃ الناس",
                ayahNumber = 5,
                arabicText = "الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ",
                romanTransliteration = "Alladhī yuwaswisu fī ṣudūrin-nās",
                urduTranslation = "جو انسانوں کے سینوں میں وسوسے ڈالتا ہے",
                englishTranslation = "Who whispers [evil] into the breasts of mankind -",
                isMemorized = false,
                repeatCount = 0
            )
        )
        list.add(
            VerseEntity(
                id = 114006,
                surahNumber = 114,
                surahNameArabic = "الناس",
                surahNameEnglish = "An-Nas",
                surahNameUrdu = "سورۃ الناس",
                ayahNumber = 6,
                arabicText = "مِنَ الْجِنَّةِ وَالنَّاسِ",
                romanTransliteration = "Minal-jinnati wan-nās",
                urduTranslation = "چاہے وہ جنوں میں سے ہو یا انسانوں میں سے",
                englishTranslation = "From among the jinn and mankind.",
                isMemorized = false,
                repeatCount = 0
            )
        )

        // 6. Surah Al-Mulk (67:1-4)
        list.add(
            VerseEntity(
                id = 67001,
                surahNumber = 67,
                surahNameArabic = "الملك",
                surahNameEnglish = "Al-Mulk",
                surahNameUrdu = "سورۃ الملک",
                ayahNumber = 1,
                arabicText = "تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ",
                romanTransliteration = "Tabārakallaḏī biyadihil-mulku wa Huwa 'alā kulli shay'in Qadīr",
                urduTranslation = "بڑی برکت والی ہے وہ ذات جس کے ہاتھ میں ساری بادشاہی ہے اور وہ ہر چیز پر قادر ہے",
                englishTranslation = "Blessed is He in whose hand is dominion, and He is over all things competent -",
                isMemorized = false,
                repeatCount = 0
            )
        )
        list.add(
            VerseEntity(
                id = 67002,
                surahNumber = 67,
                surahNameArabic = "الملك",
                surahNameEnglish = "Al-Mulk",
                surahNameUrdu = "سورۃ الملک",
                ayahNumber = 2,
                arabicText = "الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا ۚ وَهُوَ الْعَزِيزُ الْغَفُورُ",
                romanTransliteration = "Alladhī khalaqal-mawta wal-ḥayāta liyabluwakum ayyukum aḥsanu 'amalā, wa Huwal-'Azīzul-Ghafūr",
                urduTranslation = "جس نے پیدا کیا موت اور زندگی کو تاکہ تمہیں آزمائے کہ تم میں سے اچھے عمل والا کون ہے",
                englishTranslation = "[He] who created death and life to test you [as to] which of you is best in deed - and He is the Exalted in Might, the Forgiving -",
                isMemorized = false,
                repeatCount = 0
            )
        )

        // 7. Surah Al-Kawthar (108:1-3)
        list.add(
            VerseEntity(
                id = 108001,
                surahNumber = 108,
                surahNameArabic = "الكوثر",
                surahNameEnglish = "Al-Kawthar",
                surahNameUrdu = "سورۃ الکوثر",
                ayahNumber = 1,
                arabicText = "إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ",
                romanTransliteration = "Innā a'ṭaynākal-kawthar",
                urduTranslation = "بے شک ہم نے آپ کو کوثر عطا فرمائی",
                englishTranslation = "Indeed, We have granted you, [O Muhammad], al-Kawthar.",
                isMemorized = true,
                repeatCount = 8
            )
        )
        list.add(
            VerseEntity(
                id = 108002,
                surahNumber = 108,
                surahNameArabic = "الكوثر",
                surahNameEnglish = "Al-Kawthar",
                surahNameUrdu = "سورۃ الکوثر",
                ayahNumber = 2,
                arabicText = "فَصَلِّ لِرَبِّكَ وَانْحَرْ",
                romanTransliteration = "Faṣalli liRabbika wanḥar",
                urduTranslation = "پس اپنے پروردگار کے لیے نماز پڑھئے اور قربانی کیجئے",
                englishTranslation = "So pray to your Lord and sacrifice [to Him alone].",
                isMemorized = true,
                repeatCount = 8
            )
        )
        list.add(
            VerseEntity(
                id = 108003,
                surahNumber = 108,
                surahNameArabic = "الكوثر",
                surahNameEnglish = "Al-Kawthar",
                surahNameUrdu = "سورۃ الکوثر",
                ayahNumber = 3,
                arabicText = "إِنَّ شَانِئَكَ هُوَ الْأَبْتَرُ",
                romanTransliteration = "Inna shāni'aka huwal-abtar",
                urduTranslation = "یقیناً آپ کا دشمن ہی بے نام و نشان رہے گا",
                englishTranslation = "Indeed, your enemy is the one cut off.",
                isMemorized = true,
                repeatCount = 8
            )
        )

        // 8. Surah Al-Asr (103:1-3)
        list.add(
            VerseEntity(
                id = 103001,
                surahNumber = 103,
                surahNameArabic = "العصر",
                surahNameEnglish = "Al-Asr",
                surahNameUrdu = "سورۃ العصر",
                ayahNumber = 1,
                arabicText = "وَالْعَصْرِ",
                romanTransliteration = "Wal-'aṣr",
                urduTranslation = "زمانے کی قسم",
                englishTranslation = "By time,",
                isMemorized = false,
                repeatCount = 2
            )
        )
        list.add(
            VerseEntity(
                id = 103002,
                surahNumber = 103,
                surahNameArabic = "العصر",
                surahNameEnglish = "Al-Asr",
                surahNameUrdu = "سورۃ العصر",
                ayahNumber = 2,
                arabicText = "إِنَّ الْإِنسَانَ لَفِي خُسْرٍ",
                romanTransliteration = "Innal-insāna lafī khusr",
                urduTranslation = "بے شک انسان سراسر خسارے میں ہے",
                englishTranslation = "Indeed, mankind is in loss,",
                isMemorized = false,
                repeatCount = 2
            )
        )
        list.add(
            VerseEntity(
                id = 103003,
                surahNumber = 103,
                surahNameArabic = "العصر",
                surahNameEnglish = "Al-Asr",
                surahNameUrdu = "سورۃ العصر",
                ayahNumber = 3,
                arabicText = "إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ",
                romanTransliteration = "Illal-laḏīna āmanū wa 'amiluṣ-ṣāliḥāti wa tawāṣaw bil-ḥaqqi wa tawāṣaw biṣ-ṣabr",
                urduTranslation = "سوائے ان لوگوں کے جو ایمان لائے اور نیک عمل کیے اور ایک دوسرے کو حق اور صبر کی وصیت کی",
                englishTranslation = "Except for those who have believed and done righteous deeds and advised each other to truth and advised each other to patience.",
                isMemorized = false,
                repeatCount = 2
            )
        )

        return list
    }

    fun getInitialBadges(): List<BadgeEntity> {
        return listOf(
            BadgeEntity(
                id = "streak_3",
                title = "3-Day Spark",
                description = "Completed 3 consecutive days of Hifz",
                iconEmoji = "🔥",
                isUnlocked = true,
                unlockedAt = System.currentTimeMillis() - 86400000L * 2,
                category = "Streak"
            ),
            BadgeEntity(
                id = "streak_7",
                title = "7-Day Habit",
                description = "Snapchat-style unbroken 7-day learning loop",
                iconEmoji = "⚡",
                isUnlocked = false,
                category = "Streak"
            ),
            BadgeEntity(
                id = "streak_30",
                title = "Hafiz Momentum",
                description = "A full month of daily Quran connection",
                iconEmoji = "💎",
                isUnlocked = false,
                category = "Streak"
            ),
            BadgeEntity(
                id = "fatiha_done",
                title = "Al-Fatihah Master",
                description = "Fully memorized the 7 verses of the Opening Surah",
                iconEmoji = "📖",
                isUnlocked = false,
                category = "Milestone"
            ),
            BadgeEntity(
                id = "ikhlas_done",
                title = "Tawheed Champion",
                description = "Memorized the 4 verses of Surah Al-Ikhlas",
                iconEmoji = "🌟",
                isUnlocked = true,
                unlockedAt = System.currentTimeMillis() - 86400000L * 3,
                category = "Milestone"
            ),
            BadgeEntity(
                id = "kursi_done",
                title = "Throne Guardian",
                description = "Memorized the greatest Ayah in the Quran (Ayat al-Kursi)",
                iconEmoji = "👑",
                isUnlocked = false,
                category = "Milestone"
            ),
            BadgeEntity(
                id = "loop_master",
                title = "Audio Echo Master",
                description = "Listened to 50+ repeat loops for effortless retention",
                iconEmoji = "🔁",
                isUnlocked = false,
                category = "Audio"
            ),
            BadgeEntity(
                id = "fajr_bird",
                title = "Fajr Early Bird",
                description = "Completed daily goal before sunrise",
                iconEmoji = "🌙",
                isUnlocked = true,
                unlockedAt = System.currentTimeMillis() - 86400000L * 1,
                category = "Daily"
            )
        )
    }
}
