package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioPlayerState
import com.example.audio.PlaybackState
import com.example.audio.QuranAudioPlayer
import com.example.data.db.AppDatabase
import com.example.data.model.BadgeEntity
import com.example.data.model.SurahSummary
import com.example.data.model.UserProgressEntity
import com.example.data.model.VerseEntity
import com.example.data.repository.QuranRepository
import com.example.notification.ReminderManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class QuranUiState(
    val verses: List<VerseEntity> = emptyList(),
    val todayPendingVerses: List<VerseEntity> = emptyList(),
    val todayMemorizedCount: Int = 0,
    val surahSummaries: List<SurahSummary> = emptyList(),
    val badges: List<BadgeEntity> = emptyList(),
    val userProgress: UserProgressEntity = UserProgressEntity(),
    val audioState: AudioPlayerState = AudioPlayerState(),
    val showCelebration: Boolean = false,
    val celebrationStreak: Int = 0,
    val selectedVerseForShare: VerseEntity? = null,
    val selectedLibrarySurah: Int? = null,
    val isLoading: Boolean = false
)

class QuranViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = QuranRepository(database.quranDao())
    val audioPlayer = QuranAudioPlayer(application)
    private val reminderManager = ReminderManager(application)

    private val _showCelebration = MutableStateFlow(false)
    private val _celebrationStreak = MutableStateFlow(0)
    private val _selectedVerseForShare = MutableStateFlow<VerseEntity?>(null)
    private val _selectedLibrarySurah = MutableStateFlow<Int?>(null)

    data class DbState(
        val verses: List<VerseEntity> = emptyList(),
        val userProgress: UserProgressEntity = UserProgressEntity(),
        val summaries: List<SurahSummary> = emptyList(),
        val badges: List<BadgeEntity> = emptyList()
    )

    data class DialogState(
        val showCelebration: Boolean = false,
        val celebrationStreak: Int = 0,
        val shareVerse: VerseEntity? = null,
        val selectedLibrarySurah: Int? = null
    )

    private val dbState = combine(
        repository.allVerses,
        repository.userProgress,
        repository.surahSummaries,
        repository.allBadges
    ) { verses, progress, summaries, badges ->
        DbState(
            verses = verses,
            userProgress = progress ?: UserProgressEntity(),
            summaries = summaries,
            badges = badges
        )
    }

    private val dialogState = combine(
        _showCelebration,
        _celebrationStreak,
        _selectedVerseForShare,
        _selectedLibrarySurah
    ) { showCelebration, streak, shareVerse, librarySurah ->
        DialogState(
            showCelebration = showCelebration,
            celebrationStreak = streak,
            shareVerse = shareVerse,
            selectedLibrarySurah = librarySurah
        )
    }

    val uiState: StateFlow<QuranUiState> = combine(
        dbState,
        audioPlayer.playerState,
        dialogState
    ) { db, audioState, dialog ->
        val userProg = db.userProgress
        val targetSurah = userProg.targetSurahNumber
        val goalCount = userProg.dailyGoalVerses

        // Filter today's target verses
        val targetSurahVerses = db.verses.filter { it.surahNumber == targetSurah }
        val pendingInTarget = targetSurahVerses.filter { !it.isMemorized }.take(goalCount)
        val memorizedTodayInTarget = targetSurahVerses.count { it.isMemorized }

        QuranUiState(
            verses = db.verses,
            todayPendingVerses = if (pendingInTarget.isNotEmpty()) pendingInTarget else targetSurahVerses.take(goalCount),
            todayMemorizedCount = memorizedTodayInTarget,
            surahSummaries = db.summaries,
            badges = db.badges,
            userProgress = userProg,
            audioState = audioState,
            showCelebration = dialog.showCelebration,
            celebrationStreak = dialog.celebrationStreak,
            selectedVerseForShare = dialog.shareVerse,
            selectedLibrarySurah = dialog.selectedLibrarySurah,
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = QuranUiState(isLoading = true)
    )

    init {
        viewModelScope.launch {
            repository.ensureInitialData()
        }

        audioPlayer.setOnLoopFinishedListener { verseId ->
            viewModelScope.launch {
                repository.incrementRepeat(verseId)
            }
        }
    }

    fun playVerseAudio(verse: VerseEntity) {
        val currentReciter = uiState.value.userProgress.selectedReciterId
        val audioUrl = verse.getAudioUrl(currentReciter)
        val targetLoops = uiState.value.audioState.targetLoops
        audioPlayer.playVerse(verse.id, audioUrl, targetLoops)
    }

    fun togglePlayPause(verse: VerseEntity) {
        val audioState = uiState.value.audioState
        if (audioState.currentVerseId == verse.id) {
            if (audioState.playbackState == PlaybackState.PLAYING) {
                audioPlayer.pause()
            } else if (audioState.playbackState == PlaybackState.PAUSED) {
                audioPlayer.resume()
            } else {
                playVerseAudio(verse)
            }
        } else {
            playVerseAudio(verse)
        }
    }

    fun setLoopCount(loops: Int) {
        audioPlayer.setTargetLoops(loops)
    }

    fun toggleMute() {
        audioPlayer.toggleMute()
    }

    fun setPlaybackSpeed(speed: Float) {
        audioPlayer.setSpeed(speed)
    }

    fun markVerseMemorized(verseId: Int, isMemorized: Boolean) {
        viewModelScope.launch {
            val goalReached = repository.markVerseMemorized(verseId, isMemorized)
            if (goalReached && isMemorized) {
                val currentStreak = uiState.value.userProgress.currentStreak + 1
                _celebrationStreak.value = currentStreak
                _showCelebration.value = true
            }
        }
    }

    fun selectTargetSurah(surahNumber: Int) {
        viewModelScope.launch {
            repository.setTargetSurah(surahNumber)
        }
    }

    fun setDailyGoal(goal: Int) {
        viewModelScope.launch {
            repository.setDailyGoal(goal)
        }
    }

    fun setReciter(reciterId: String) {
        viewModelScope.launch {
            repository.setReciter(reciterId)
            audioPlayer.setReciter(reciterId)
        }
    }

    fun setDefaultLoop(loops: Int) {
        viewModelScope.launch {
            repository.setDefaultLoop(loops)
            audioPlayer.setTargetLoops(loops)
        }
    }

    fun updateReminderSettings(time: String, enabled: Boolean) {
        viewModelScope.launch {
            repository.updateReminder(time, enabled)
        }
    }

    fun useStreakFreeze() {
        viewModelScope.launch {
            repository.useFreeze()
        }
    }

    fun openShareDialog(verse: VerseEntity) {
        _selectedVerseForShare.value = verse
    }

    fun closeShareDialog() {
        _selectedVerseForShare.value = null
    }

    fun dismissCelebration() {
        _showCelebration.value = false
    }

    fun selectLibrarySurah(surahNumber: Int?) {
        _selectedLibrarySurah.value = surahNumber
    }

    fun sendTestNotification() {
        val state = uiState.value
        val pendingCount = state.todayPendingVerses.count { !it.isMemorized }
        val streak = state.userProgress.currentStreak
        val surahName = state.todayPendingVerses.firstOrNull()?.surahNameEnglish ?: "Al-Fatihah"
        reminderManager.sendEngagementReminder(pendingCount, streak, surahName)
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.release()
    }
}
