package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.QuranUiState
import com.example.ui.QuranViewModel
import com.example.ui.components.DailyProgressCard
import com.example.ui.components.HifzRecallCard
import com.example.ui.components.RedPendingBanner
import com.example.ui.components.StreakBanner
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldLight

@Composable
fun TodayScreen(
    uiState: QuranUiState,
    viewModel: QuranViewModel,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pendingVerses = uiState.todayPendingVerses
    val memorizedInTarget = uiState.todayMemorizedCount
    val dailyGoal = uiState.userProgress.dailyGoalVerses
    val currentStreak = uiState.userProgress.currentStreak
    val uncompletedCount = pendingVerses.count { !it.isMemorized }
    val isGoalDone = memorizedInTarget >= dailyGoal && dailyGoal > 0

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("today_screen_list"),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Hero Banner Header with Islamic Art
        item {
            IslamicHeroHeader(
                onSendTestNotification = { viewModel.sendTestNotification() },
                onNavigateToSettings = onNavigateToSettings
            )
        }

        // Streak & Fire Banner (Snapchat Retention Loop)
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                StreakBanner(
                    currentStreak = currentStreak,
                    isGoalDoneToday = isGoalDone,
                    freezesAvailable = uiState.userProgress.streakFreezeAvailable,
                    onUseFreeze = { viewModel.useStreakFreeze() }
                )
            }
        }

        // Red Notification Badge Banner (Pulsing trigger for pending verses)
        if (uncompletedCount > 0) {
            item {
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    RedPendingBanner(
                        pendingCount = uncompletedCount,
                        onClick = { /* already on screen */ }
                    )
                }
            }
        }

        // Apple Fitness Style Dual Ring
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                DailyProgressCard(
                    memorizedCount = memorizedInTarget.coerceAtMost(dailyGoal),
                    goalCount = dailyGoal,
                    audioLoopsDone = uiState.userProgress.totalAudioLoopsDone % 10,
                    audioLoopsTarget = uiState.audioState.targetLoops.let { if (it <= 0) 5 else it }
                )
            }
        }

        // Surah Switcher Chips
        item {
            Column(modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Current Surah Target",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Goal: ${dailyGoal} Ayat/Day",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(uiState.surahSummaries) { surah ->
                        val isSelected = surah.number == uiState.userProgress.targetSurahNumber
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.selectTargetSurah(surah.number) },
                            label = {
                                Text(
                                    text = "${surah.nameEnglish} (${surah.memorizedVerses}/${surah.totalVerses})",
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        // Today's Active Ayat List
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Today's Micro-Learning Verses",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "${pendingVerses.size} Verses",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (pendingVerses.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = EmeraldPrimary)
                }
            }
        } else {
            items(pendingVerses, key = { it.id }) { verse ->
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    HifzRecallCard(
                        verse = verse,
                        playerState = uiState.audioState,
                        onPlayPause = { viewModel.togglePlayPause(verse) },
                        onSelectLoopCount = { loops -> viewModel.setLoopCount(loops) },
                        onToggleMute = { viewModel.toggleMute() },
                        onSelectSpeed = { speed -> viewModel.setPlaybackSpeed(speed) },
                        onToggleMemorized = { isMemorized ->
                            viewModel.markVerseMemorized(verse.id, isMemorized)
                        },
                        onShare = { viewModel.openShareDialog(verse) }
                    )
                }
            }
        }
    }
}

@Composable
fun IslamicHeroHeader(
    onSendTestNotification: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(180.dp)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF062B1F),
                        EmeraldDeep,
                        Color(0xFF0E4331)
                    )
                )
            )
    ) {
        // Delicate Islamic Star and Crescent Canvas
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Soft glowing background circle
            drawCircle(
                color = Color(0x1AD4AF37),
                radius = 120.dp.toPx(),
                center = androidx.compose.ui.geometry.Offset(w * 0.85f, h * 0.35f)
            )

            // Golden Crescent Moon
            val moonCenter = androidx.compose.ui.geometry.Offset(w * 0.88f, h * 0.42f)
            val outerRadius = 32.dp.toPx()
            drawCircle(
                color = GoldAccent.copy(alpha = 0.85f),
                radius = outerRadius,
                center = moonCenter
            )
            // Cutout for crescent shape
            drawCircle(
                color = EmeraldDeep,
                radius = outerRadius * 0.86f,
                center = androidx.compose.ui.geometry.Offset(moonCenter.x - 10.dp.toPx(), moonCenter.y - 6.dp.toPx())
            )

            // Islamic Star near crescent
            drawCircle(
                color = GoldLight,
                radius = 3.dp.toPx(),
                center = androidx.compose.ui.geometry.Offset(moonCenter.x - 22.dp.toPx(), moonCenter.y - 12.dp.toPx())
            )

            // Scattered twinkling ambient stars
            val stars = listOf(
                androidx.compose.ui.geometry.Offset(w * 0.15f, h * 0.25f),
                androidx.compose.ui.geometry.Offset(w * 0.45f, h * 0.18f),
                androidx.compose.ui.geometry.Offset(w * 0.65f, h * 0.32f),
                androidx.compose.ui.geometry.Offset(w * 0.78f, h * 0.8f),
                androidx.compose.ui.geometry.Offset(w * 0.3f, h * 0.75f)
            )
            stars.forEach { star ->
                drawCircle(
                    color = Color.White.copy(alpha = 0.45f),
                    radius = 1.8.dp.toPx(),
                    center = star
                )
            }
        }

        // Top Bar content inside header
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Hifz Daily",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Micro-learning • 1-2 Ayat Daily",
                        style = MaterialTheme.typography.bodySmall,
                        color = GoldAccent,
                        fontWeight = FontWeight.Medium
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onSendTestNotification,
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color.White.copy(alpha = 0.15f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "Test Notification Reminder",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = onNavigateToSettings,
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color.White.copy(alpha = 0.15f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Settings",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Inspiring Quranic Motive at bottom of header
            Row(
                modifier = Modifier
                    .background(Color.Black.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "اقْرَأْ بِاسْمِ رَبِّكَ",
                    color = GoldLight,
                    fontSize = 14.sp,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "• \"Recite in the name of your Lord\"",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 11.sp
                )
            }
        }
    }
}
