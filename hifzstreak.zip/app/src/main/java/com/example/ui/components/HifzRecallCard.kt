package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioPlayerState
import com.example.data.model.VerseEntity
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.FlameOrange
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldDark

@Composable
fun HifzRecallCard(
    verse: VerseEntity,
    playerState: AudioPlayerState,
    onPlayPause: () -> Unit,
    onSelectLoopCount: (Int) -> Unit,
    onToggleMute: () -> Unit,
    onSelectSpeed: (Float) -> Unit,
    onToggleMemorized: (Boolean) -> Unit,
    onShare: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Memorization / Recall Test Mode States
    var isTestRecallMode by remember { mutableStateOf(false) }
    var isArabicHidden by remember { mutableStateOf(false) }
    var showTranslation by remember { mutableStateOf(true) }
    var showTransliteration by remember { mutableStateOf(true) }

    val cardBorderColor by animateColorAsState(
        targetValue = if (verse.isMemorized) EmeraldLight else Color(0xFFE2EBE5),
        label = "borderColor"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.5.dp, cardBorderColor, RoundedCornerShape(24.dp)),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header: Surah Name, Ayah Tag, Test Mode Toggle & Share
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(GoldContainer, RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "${verse.surahNameEnglish} ${verse.surahNumber}:${verse.ayahNumber}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = GoldDark
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = verse.surahNameUrdu,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Recall Test Mode Toggle Chip
                    FilterChip(
                        selected = isTestRecallMode,
                        onClick = {
                            isTestRecallMode = !isTestRecallMode
                            if (isTestRecallMode) {
                                isArabicHidden = true
                            } else {
                                isArabicHidden = false
                            }
                        },
                        label = {
                            Text(
                                text = if (isTestRecallMode) "Testing 🧠" else "Hifz Test",
                                fontSize = 11.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = FlameOrange,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.height(32.dp)
                    )

                    Spacer(modifier = Modifier.width(4.dp))

                    IconButton(
                        onClick = onShare,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share Verse",
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Main Arabic Quran Display (With Recall Blank/Mask mode support)
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = if (isTestRecallMode) Color(0xFFF9F6EE) else Color(0xFFF4F9F6),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isTestRecallMode) GoldAccent.copy(alpha = 0.5f) else Color.Transparent
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (isArabicHidden) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(vertical = 12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = FlameOrange,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Recite this Ayah from memory!",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = FlameOrange
                            )
                            Text(
                                text = "Listen to audio if needed, then tap below to reveal and check",
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedButton(
                                onClick = { isArabicHidden = false },
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = EmeraldPrimary
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Visibility,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Reveal Arabic Text")
                            }
                        }
                    } else {
                        // Authentic Arabic Quran Text
                        Text(
                            text = verse.arabicText,
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontSize = 26.sp,
                                lineHeight = 46.sp,
                                fontFamily = FontFamily.Serif
                            ),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Medium,
                            color = EmeraldDeep,
                            modifier = Modifier.fillMaxWidth()
                        )

                        if (isTestRecallMode) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Tap to hide again",
                                style = MaterialTheme.typography.labelSmall,
                                color = FlameOrange,
                                modifier = Modifier
                                    .clickable { isArabicHidden = true }
                                    .padding(4.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Roman Script Transliteration
            AnimatedVisibility(visible = showTransliteration) {
                Column {
                    Text(
                        text = verse.romanTransliteration,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF2C5E43),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            // Urdu Tarjuma (اردو ترجمہ)
            AnimatedVisibility(visible = showTranslation) {
                Column {
                    Text(
                        text = "اردو: ${verse.urduTranslation}",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            lineHeight = 24.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Start
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    // English Translation
                    Text(
                        text = "English: ${verse.englishTranslation}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Translation toggle button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                Text(
                    text = if (showTranslation) "Hide Translations" else "Show Translations",
                    style = MaterialTheme.typography.labelSmall,
                    color = EmeraldLight,
                    modifier = Modifier
                        .clickable { showTranslation = !showTranslation }
                        .padding(4.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Audio Reciter & Repeat Loop Controls
            AudioRepeatControls(
                playerState = playerState,
                verseId = verse.id,
                onPlayPause = onPlayPause,
                onSelectLoopCount = onSelectLoopCount,
                onToggleMute = onToggleMute,
                onSelectSpeed = onSelectSpeed
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Bottom Action: Mark as Memorized (Big satisfying engagement button)
            Button(
                onClick = { onToggleMemorized(!verse.isMemorized) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (verse.isMemorized) EmeraldPrimary else Color(0xFFE8F3ED),
                    contentColor = if (verse.isMemorized) Color.White else EmeraldDeep
                )
            ) {
                Icon(
                    imageVector = if (verse.isMemorized) Icons.Default.CheckCircle else Icons.Outlined.CheckCircleOutline,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (verse.isMemorized) "Memorized ✓ (Tap to Undo)" else "Mark as Memorized",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    }
}
