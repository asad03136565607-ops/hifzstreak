package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SurahSummary
import com.example.data.model.VerseEntity
import com.example.ui.QuranUiState
import com.example.ui.QuranViewModel
import com.example.ui.components.HifzRecallCard
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldDark

@Composable
fun SurahLibraryScreen(
    uiState: QuranUiState,
    viewModel: QuranViewModel,
    modifier: Modifier = Modifier
) {
    var expandedSurahId by remember { mutableStateOf<Int?>(uiState.userProgress.targetSurahNumber) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("surah_library_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 20.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(bottom = 16.dp)) {
                Text(
                    text = "Surah Memorization Library",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldDeep
                )
                Text(
                    text = "Select any Surah as your active daily Hifz roadmap or review verses",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        items(uiState.surahSummaries, key = { it.number }) { surah ->
            val isTarget = surah.number == uiState.userProgress.targetSurahNumber
            val isExpanded = expandedSurahId == surah.number
            val surahVerses = uiState.verses.filter { it.surahNumber == surah.number }

            SurahSummaryCard(
                surah = surah,
                isTarget = isTarget,
                isExpanded = isExpanded,
                surahVerses = surahVerses,
                uiState = uiState,
                viewModel = viewModel,
                onToggleExpand = {
                    expandedSurahId = if (isExpanded) null else surah.number
                },
                onSetAsTarget = {
                    viewModel.selectTargetSurah(surah.number)
                }
            )

            Spacer(modifier = Modifier.height(12.dp))
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
fun SurahSummaryCard(
    surah: SurahSummary,
    isTarget: Boolean,
    isExpanded: Boolean,
    surahVerses: List<VerseEntity>,
    uiState: QuranUiState,
    viewModel: QuranViewModel,
    onToggleExpand: () -> Unit,
    onSetAsTarget: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isTarget) 1.5.dp else 1.dp,
                color = if (isTarget) EmeraldPrimary else Color(0xFFE2EBE5),
                shape = RoundedCornerShape(20.dp)
            ),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isTarget) 3.dp else 1.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleExpand() }
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Surah Number Badge
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(
                            if (isTarget) EmeraldPrimary else EmeraldContainer,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = surah.number.toString(),
                        fontWeight = FontWeight.Bold,
                        color = if (isTarget) Color.White else EmeraldDeep,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                // Surah English & Urdu titles
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = surah.nameEnglish,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (isTarget) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "🎯 ACTIVE",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldPrimary,
                                modifier = Modifier
                                    .background(EmeraldContainer, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "${surah.nameUrdu} • ${surah.memorizedVerses}/${surah.totalVerses} Ayat memorized",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Progress Bar
                    LinearProgressIndicator(
                        progress = { surah.progressPercent },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp),
                        color = if (surah.isComplete) GoldAccent else EmeraldPrimary,
                        trackColor = Color(0xFFE8F1EC),
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Arabic Calligraphy Name
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = surah.nameArabic,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = FontFamily.Serif,
                            fontSize = 20.sp
                        ),
                        color = EmeraldDeep
                    )

                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Expand Surah",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Expanded content: Action bar and list of verses
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF7FAF8))
                        .padding(16.dp)
                ) {
                    if (!isTarget) {
                        Button(
                            onClick = onSetAsTarget,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                        ) {
                            Text("Set as Today's Hifz Target 🎯")
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                    }

                    Text(
                        text = "Verses in ${surah.nameEnglish}:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldDeep
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    surahVerses.forEach { verse ->
                        HifzRecallCard(
                            verse = verse,
                            playerState = uiState.audioState,
                            onPlayPause = { viewModel.togglePlayPause(verse) },
                            onSelectLoopCount = { loops -> viewModel.setLoopCount(loops) },
                            onToggleMute = { viewModel.toggleMute() },
                            onSelectSpeed = { speed -> viewModel.setPlaybackSpeed(speed) },
                            onToggleMemorized = { isMemorized ->
                                viewModel.markVerseMemorized(verse.id, isMemorized)
                            },
                            onShare = { viewModel.openShareDialog(verse) },
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    }
                }
            }
        }
    }
}
