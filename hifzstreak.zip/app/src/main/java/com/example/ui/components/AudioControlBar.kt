package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioPlayerState
import com.example.audio.PlaybackState
import com.example.audio.QuranAudioPlayer
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldDark

@Composable
fun AudioRepeatControls(
    playerState: AudioPlayerState,
    verseId: Int,
    onPlayPause: () -> Unit,
    onSelectLoopCount: (Int) -> Unit,
    onToggleMute: () -> Unit,
    onSelectSpeed: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val isPlayingThisVerse = playerState.currentVerseId == verseId &&
            (playerState.playbackState == PlaybackState.PLAYING || playerState.playbackState == PlaybackState.PREPARING)
    val isPausedThisVerse = playerState.currentVerseId == verseId && playerState.playbackState == PlaybackState.PAUSED

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = EmeraldContainer.copy(alpha = 0.5f),
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Main Control Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Play / Pause Circle Button
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .background(EmeraldPrimary, CircleShape)
                            .clickable { onPlayPause() },
                        contentAlignment = Alignment.Center
                    ) {
                        if (playerState.currentVerseId == verseId && playerState.playbackState == PlaybackState.PREPARING) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else if (isPlayingThisVerse) {
                            Icon(
                                imageVector = Icons.Default.Pause,
                                contentDescription = "Pause Recitation",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Play Recitation",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = if (isPlayingThisVerse) "Listening on Loop" else if (isPausedThisVerse) "Paused" else "Audio Recitation",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldDeep
                        )

                        // Loop status e.g. "Loop 2 of 5" or "Loop 3 of ∞"
                        if (isPlayingThisVerse || isPausedThisVerse) {
                            val loopStr = if (playerState.targetLoops == -1) {
                                "Loop ${playerState.currentLoop} of ∞ (Infinite)"
                            } else {
                                "Loop ${playerState.currentLoop} of ${playerState.targetLoops}"
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = null,
                                    tint = GoldDark,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = loopStr,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = GoldDark,
                                    fontSize = 11.sp
                                )
                            }
                        } else {
                            Text(
                                text = "Select loop count to memorize effortlessly",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                // Mute / Unmute
                IconButton(
                    onClick = onToggleMute,
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        imageVector = if (playerState.isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                        contentDescription = "Mute/Unmute",
                        tint = if (playerState.isMuted) Color.Gray else EmeraldPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Repeat Loop Selection Row (1x, 3x, 5x, 10x, ∞ Loop)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Repeat,
                        contentDescription = "Repeat",
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Loop:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldPrimary
                    )
                }

                val loopOptions = listOf(1, 3, 5, 10, -1)
                loopOptions.forEach { loops ->
                    val isSelected = playerState.targetLoops == loops
                    val label = if (loops == -1) "∞" else "${loops}x"

                    Box(
                        modifier = Modifier
                            .background(
                                color = if (isSelected) EmeraldPrimary else Color.White,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { onSelectLoopCount(loops) }
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else EmeraldDeep
                        )
                    }
                }
            }

            // Speed chips row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.End
            ) {
                Text(
                    text = "Speed:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 10.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                listOf(0.75f, 1.0f, 1.25f).forEach { speed ->
                    val isSpeedSelected = playerState.playbackSpeed == speed
                    Text(
                        text = "${speed}x",
                        fontSize = 10.sp,
                        fontWeight = if (isSpeedSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSpeedSelected) EmeraldPrimary else Color.Gray,
                        modifier = Modifier
                            .clickable { onSelectSpeed(speed) }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Error Message
            if (playerState.currentVerseId == verseId && playerState.errorMessage != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = playerState.errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 11.sp
                )
            }
        }
    }
}
