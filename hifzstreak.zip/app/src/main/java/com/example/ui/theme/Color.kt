package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Emerald Green & Gold Luxury Palette
val EmeraldDeep = Color(0xFF0A3728)
val EmeraldPrimary = Color(0xFF0F5B3F)
val EmeraldMedium = Color(0xFF1B7A56)
val EmeraldLight = Color(0xFF2FA376)
val EmeraldContainer = Color(0xFFE2F3EB)
val EmeraldDarkContainer = Color(0xFF132B22)

// Gold Accents
val GoldAccent = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF3E5AB)
val GoldDark = Color(0xFFAA8012)
val GoldContainer = Color(0xFFFFF7DD)

// Fire / Streak / Retention Red Accents
val FlameOrange = Color(0xFFFF6D00)
val FlameYellow = Color(0xFFFFD600)
val UrgentRed = Color(0xFFE53935)
val UrgentRedContainer = Color(0xFFFFEBEE)

// Neutral & Backgrounds
val OffWhiteSurface = Color(0xFFF8FAF8)
val CleanWhite = Color(0xFFFFFFFF)
val MutedSlate = Color(0xFF607274)
val SubtleBorder = Color(0xFFE0E7E3)

// Dark Theme colors
val DarkSurface = Color(0xFF101714)
val DarkSurfaceVariant = Color(0xFF18221D)
val DarkCardBorder = Color(0xFF25372E)
val LightText = Color(0xFFEDF2EE)
val LightMutedText = Color(0xFF9FB1A7)
