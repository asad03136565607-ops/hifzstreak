package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.FlameOrange
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldLight

@Composable
fun DailyProgressCard(
    memorizedCount: Int,
    goalCount: Int,
    audioLoopsDone: Int,
    audioLoopsTarget: Int,
    modifier: Modifier = Modifier
) {
    val versesProgress = if (goalCount > 0) (memorizedCount.toFloat() / goalCount).coerceIn(0f, 1f) else 0f
    val loopsProgress = if (audioLoopsTarget > 0) (audioLoopsDone.toFloat() / audioLoopsTarget).coerceIn(0f, 1f) else 0f

    val animatedVersesProgress by animateFloatAsState(
        targetValue = versesProgress,
        animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
        label = "versesProgress"
    )

    val animatedLoopsProgress by animateFloatAsState(
        targetValue = loopsProgress,
        animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
        label = "loopsProgress"
    )

    val isGoalCompleted = memorizedCount >= goalCount && goalCount > 0

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Dual Apple Fitness style rings
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(110.dp)
            ) {
                Canvas(modifier = Modifier.size(110.dp)) {
                    val outerStroke = 10.dp.toPx()
                    val innerStroke = 7.dp.toPx()
                    val center = Offset(size.width / 2, size.height / 2)

                    // Outer Ring Background (Memorization)
                    val outerRadius = (size.minDimension - outerStroke) / 2
                    drawCircle(
                        color = Color(0xFFE8F2EC),
                        radius = outerRadius,
                        center = center,
                        style = Stroke(width = outerStroke)
                    )

                    // Outer Ring Progress
                    val outerBrush = Brush.sweepGradient(
                        colors = listOf(EmeraldLight, EmeraldPrimary, GoldAccent, EmeraldLight),
                        center = center
                    )
                    drawArc(
                        brush = outerBrush,
                        startAngle = -90f,
                        sweepAngle = animatedVersesProgress * 360f,
                        useCenter = false,
                        topLeft = Offset(outerStroke / 2, outerStroke / 2),
                        size = Size(size.width - outerStroke, size.height - outerStroke),
                        style = Stroke(width = outerStroke, cap = StrokeCap.Round)
                    )

                    // Inner Ring Background (Audio Loops)
                    val innerRadius = outerRadius - outerStroke - 4.dp.toPx()
                    drawCircle(
                        color = Color(0xFFFFF6E0),
                        radius = innerRadius,
                        center = center,
                        style = Stroke(width = innerStroke)
                    )

                    // Inner Ring Progress
                    val innerBrush = Brush.sweepGradient(
                        colors = listOf(GoldAccent, FlameOrange, GoldLight, GoldAccent),
                        center = center
                    )
                    val innerOffset = outerStroke + 4.dp.toPx() + innerStroke / 2
                    val innerDiameter = innerRadius * 2
                    drawArc(
                        brush = innerBrush,
                        startAngle = -90f,
                        sweepAngle = animatedLoopsProgress * 360f,
                        useCenter = false,
                        topLeft = Offset(center.x - innerRadius, center.y - innerRadius),
                        size = Size(innerDiameter, innerDiameter),
                        style = Stroke(width = innerStroke, cap = StrokeCap.Round)
                    )
                }

                // Center Indicator
                if (isGoalCompleted) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(EmeraldPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Goal Achieved",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${(versesProgress * 100).toInt()}%",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Hifz",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 9.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(20.dp))

            // Metrics Legend & Call to Action
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isGoalCompleted) "🎉 Today's Goal Complete!" else "Today's Micro-Goal",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isGoalCompleted) EmeraldPrimary else MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Outer Ring Legend: Verses
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(EmeraldPrimary, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.MenuBook,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = EmeraldPrimary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Ayat: $memorizedCount / $goalCount memorized",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Inner Ring Legend: Audio Loops
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(GoldAccent, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.Headphones,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = GoldAccent
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Listening: $audioLoopsDone loops heard",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (!isGoalCompleted) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "⚡ Just ${goalCount - memorizedCount} ayat left to keep flame alive!",
                        style = MaterialTheme.typography.labelSmall,
                        color = FlameOrange,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
