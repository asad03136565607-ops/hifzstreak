package com.example

import com.example.data.db.QuranInitialData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun initialData_containsEssentialSurahs() {
        val verses = QuranInitialData.getInitialVerses()
        assertTrue("Should contain initial verses", verses.isNotEmpty())

        val fatiha = verses.filter { it.surahNumber == 1 }
        assertEquals(7, fatiha.size)

        val firstAyah = fatiha.first()
        assertEquals(1, firstAyah.ayahNumber)
        assertEquals(
            "https://everyayah.com/data/Alafasy_128kbps/001001.mp3",
            firstAyah.getAudioUrl("Alafasy_128kbps")
        )
    }

    @Test
    fun initialBadges_containsMilestones() {
        val badges = QuranInitialData.getInitialBadges()
        assertTrue(badges.any { it.id == "streak_3" })
        assertTrue(badges.any { it.id == "fatiha_done" })
    }
}
